#include<iostream>
using namespace std;


void bubleSort(int a[]){
	for(int i=0 ;i<5;i++){ //outer loop condition
		for(int j=0 ; j<(5-i-1) ;j++){ //inner loop 
			if(a[j]>a[j+1]) {
				int temp=a[j]; //swap olarak a[j] atal�m en son temple eri�elim
				a[j]=a[j+1];
				a[j+1]=temp; 
			
			}
		}
	}
	
	
}

int main(){
	int myarray[5];
	cout<<"enter 5 integers in any order:"<<endl;
	for(int i=0;i<5;i++){
		cin>>myarray[i];
	}
	cout<<"before sorting:"<<endl;
	for(int i=0;i<5;i++){
		cout<<myarray[i]<<" "<<endl;
	}
	bubleSort(myarray); //myarray is address
	
	cout<<"after sorting:"<<endl;
	for(int i=0;i<5;i++){
		cout<<myarray[i]<<" ";
	}
	
	return 0;
}
