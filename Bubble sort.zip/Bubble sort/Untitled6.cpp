//Kullan�c�n�n girdi�i n adet pozitif tam say�lar�n bubble sort algoritmas� ile s�ralanmas�
#include <iostream> // cin, cout vs.
using namespace std; // std:: her seferinde yazmak yerine burda belirtiyorum
 
int main(){
	int n;
	int temp; // Ge�i�i de�i�ken tutar
	
	// Girilecek say� adetinin kullan�c�dan istenmesi.
	cout << "how many numbers will you enter: ";
	cin >> n;
	
	// n elemanl� say� dizisi.
	int sayi[n];
	
	// n adet say�n�n kullan�c�dan istenmesi.
	cout << endl << "enter the number  " << endl;
	for(int i=0; i<n; i++){
		cout << i+1  << ". enter the number ";
		cin >> sayi[i];
	}
	
	// Bubble Sort (Kabarc�k S�ralama) Algoritmas�.  For each element moving through the list
	for(int i=0; i<n; i++){
		for(int j=i; j<n; j++){
			// Dizideki say� �iftlerini kontrol et. Compare elements  
			if(sayi[i] > sayi[j]){
				// Yanl�� s�ralanm�� say� �iftlerinin yerini de�i�tir.swap 
				temp = sayi[i];
				sayi[i] = sayi[j];
				sayi[j] = temp;
			}
		}
	}
	
	// Sonucun ekranda g�sterilmesi.
	cout << endl;
	cout << "Entered " << n << " the number from small to large is sorted out: ";
	for(int i=0; i<n; i++){
		cout << sayi[i] << " ";
	}
	cout << endl;
 
	system("PAUSE");
	return 0;
}
